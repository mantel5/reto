package model;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface IMotorSql {
    public void connect();
    public int execute(String sql) throws SQLException;
    public ResultSet executeQuery(String sql);
    public void disconnected();

    int executeUpdate(String sql);
}
